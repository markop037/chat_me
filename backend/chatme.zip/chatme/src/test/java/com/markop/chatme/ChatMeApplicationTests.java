package com.markop.chatme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatMeApplicationTests {

	@Test
	void contextLoads() {
	}

}
